import mysql.connector
from decimal import Decimal

# Connecting to Database
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="TakaisBae25!",
    database="bacchus_winery_v2"
)

cursor = connection.cursor()

def report_supplier_delivery():
    print("\n---- SUPPLIER DELIVERY PERFORMANCE ----")

    query = """
    SELECT
        s.Supplier_Name,
        DATE_FORMAT(sh.Expected_Delivery, '%Y-%m') AS Delivery_Month,
        COUNT(*) AS Total_Shipments,
        SUM(CASE WHEN sh.Actual_Delivery <= sh.Expected_Delivery THEN 1 ELSE 0 END) AS On_Time,
        SUM(CASE WHEN sh.Actual_Delivery > sh.Expected_Delivery THEN 1 ELSE 0 END) AS Late,
        ROUND(AVG(DATEDIFF(sh.Actual_Delivery, sh.Expected_Delivery)), 1) AS Avg_Days_Late
    FROM Shipment sh
    JOIN Supplier s ON sh.Supplier_ID = s.Supplier_ID
    GROUP BY s.Supplier_Name, Delivery_Month
    ORDER BY s.Supplier_Name, Delivery_Month;
    """

    cursor.execute(query)
    rows = cursor.fetchall()
    if rows:
        print("Supplier_Name | Delivery_Month | Total_Shipments | On_Time | Late | Avg_Days_Late")
        for row in rows:
            clean_row = []
            for value in row:
                if isinstance(value, Decimal):
                    value = float(value)
                clean_row.append(value)
            
            print(tuple(clean_row))
    else:
        print("No delivery records found.")

# Run the report
report_supplier_delivery()

# Close the connection
cursor.close()
connection.close()

# References (for instructor only):
# 
# Liang, Y. D. (2020). Introduction to Java programming and data structures (13th ed.,
# Chapter 2: Elementary Programming). Pearson.
#
# Liang, Y. D. (2020). Introduction to Java programming and data structures (13th ed.,
# Chapter 5: Loops). Pearson.
#
# W3Schools. (n.d.). Python casting. https://www.w3schools.com/python/python_casting.asp
#
# W3Schools. (n.d.). Python for loops. https://www.w3schools.com/python/python_for_loops.asp
#
# W3Schools. (n.d.). Python isinstance(). https://www.w3schools.com/python/ref_func_isinstance.asp
